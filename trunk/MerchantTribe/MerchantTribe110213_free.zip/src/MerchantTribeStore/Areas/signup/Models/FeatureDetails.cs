﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MerchantTribeStore.Areas.signup.Models
{
    public class FeatureDetails
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string ImageId { get; set; }
    }
}