
namespace MerchantTribeStore
{

    partial class BVAdmin_BVAdminPopup : System.Web.UI.MasterPage
    {
    }
}

