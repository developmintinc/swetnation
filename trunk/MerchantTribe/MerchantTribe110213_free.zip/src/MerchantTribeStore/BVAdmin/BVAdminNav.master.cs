using MerchantTribe.Commerce;

namespace MerchantTribeStore
{

    partial class BVAdmin_BVAdminNav : System.Web.UI.MasterPage
    {
        protected override void OnLoad(System.EventArgs e)
        {
            base.OnLoad(e);
        }
    }

}