
namespace MerchantTribeStore
{

    partial class BVAdmin_Configuration_NavMenu : System.Web.UI.UserControl
    {

    }
}