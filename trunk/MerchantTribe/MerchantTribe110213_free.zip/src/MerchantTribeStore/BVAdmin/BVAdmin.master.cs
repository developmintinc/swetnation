using MerchantTribe.Commerce;

namespace MerchantTribeStore
{

    partial class BVAdmin_BVAdmin : System.Web.UI.MasterPage
    {
        protected override void OnLoad(System.EventArgs e)
        {
            base.OnLoad(e);
        }
    }
}