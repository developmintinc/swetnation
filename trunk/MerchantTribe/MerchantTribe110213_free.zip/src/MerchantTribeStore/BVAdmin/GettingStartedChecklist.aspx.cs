
namespace MerchantTribeStore
{

    partial class BVAdmin_GettingStartedChecklist : System.Web.UI.Page
    {

    }
}