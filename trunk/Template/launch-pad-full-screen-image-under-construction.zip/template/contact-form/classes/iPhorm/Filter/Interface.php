<?php

/**
 * Filter Interface
 */
interface iPhorm_Filter_Interface
{
    public function filter($value);
}