<?php

interface iPhorm_SuccessHandler_Interface
{
    public function run();
}