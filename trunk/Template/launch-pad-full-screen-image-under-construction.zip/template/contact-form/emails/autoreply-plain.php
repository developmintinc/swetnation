<?php echo $userMessage->getSubject(); ?>

Just to let you know we received your enquiry and will get back to you as soon as possible.