Thanks for purchasing!

Please find the documentation and installation guide in documentation/index.html

You will find the template version in the template folder

The Photoshop PSD files are in the resources folder

We would love it if you would rate the item on ThemeForest if you like it :)